import json,os
from sys import getsizeof

'''
The function validate_file valids both filepath and filesize and raises an 
exception when the path is invalid or filesize exceeds 1GB.
'''

def validate_file(file_path):
    if not os.path.exists(file_path):raise Exception("Invalid file path")
    if os.stat(file_path).st_size > 1073741824:raise Exception("File size exceeded 1GB")

'''
The function validate_key valids key length and raises an 
exception when the key length exceeds 32 characters.
'''

def validate_key(key):
    if len(key) > 32:raise Exception("Max key length allowed is 32 chars")

'''
The function validate_value valids value size and raises an 
exception when the value size exceeds 16 kilobytes.
'''

def validate_value(value):
    if getsizeof(value) > 16000:raise Exception("Max value size allowed is 16KB")

'''
The function create_data is responsible for creating JSON data, for the given filepath, key and value as 
arguments and raises an exception, when key already exists. 
'''

def create_data(file_path,key,value):
    validate_file(file_path)
    validate_key(key)
    validate_value(value)
    file = open(file_path,"r")
    obj = json.load(file)
    file.close()
    if key in obj:
        raise Exception("Key already exists")
       #return "data_exist"
    else:
        obj[key] = value
        file = open(file_path,"w")
        json.dump(obj,file)
        file.close()
        print("data_created")
        #return "data_created"
'''
The function read_data is responsible for reading the JSON data, for the provided key,if 
key is not found raises key not found as an exception.
'''
def read_data(file_path,key):
    validate_file(file_path)
    validate_key(key)
    validate_value(value)file = open(file_path,"r")
    obj = json.load(file)
    file.close()
    if key in obj:
        print(obj[key])
        #return "data_read"
    else:
        raise Exception("Key does not exists")
        #return "data_not_found"
    
'''
The function delete_data is responsible for deleting the JSON data, for the provided key, 
if key is not found raises key not found as an exception.
'''
def delete_data(file_path,key):
    validate_file(file_path)
    validate_key(key)
    validate_value(value)
    file = open(file_path,"r")
    obj = json.load(file)
    file.close()
    try:
        if obj[key]:
            delete_key = obj[key]
            del obj[key]
            file = open(file_path,"w")
            json.dump(obj,file)
            print(delete_key,"deleted")
            #return "data_deleted"
    except:
        raise Exception("Key does not exists")
        #return "data_not_found"